const transactions = JSON.parse(localStorage.getItem("transactions")) || [];

const formatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "INR",
  signDisplay: "always",
});

const list = document.getElementById("transactionList");
const form = document.getElementById("transactionForm");
const status = document.getElementById("status");
const balance = document.getElementById("balance");
const income = document.getElementById("income");
const expense = document.getElementById("expense");

// Chart.js setup
const ctx = document.getElementById("transactionChart").getContext("2d");

let chart = new Chart(ctx, {
  type: "line", // Line chart type
  data: {
    labels: [],
    datasets: [
      {
        label: "Income",
        data: [],
        borderColor: "green",
        fill: false,
        tension: 0.1,
        pointBackgroundColor: "green",
      },
      {
        label: "Expense",
        data: [],
        borderColor: "red",
        fill: false,
        tension: 0.1,
        pointBackgroundColor: "red",
      },
    ],
  },
  options: {
    responsive: true,
    scales: {
      x: {
        type: "category", // X-axis as a category
      },
      y: {
        ticks: {
          beginAtZero: true,
          callback: function (value) {
            return "₹" + value; // Format the Y-axis values as currency
          },
        },
      },
    },
  },
});

form.addEventListener("submit", addTransaction);

function updateTotal() {
  const incomeTotal = transactions
    .filter((trx) => trx.type === "income")
    .reduce((total, trx) => total + trx.amount, 0);

  const expenseTotal = transactions
    .filter((trx) => trx.type === "expense")
    .reduce((total, trx) => total + trx.amount, 0);

  const balanceTotal = incomeTotal - expenseTotal;

  balance.textContent = formatter.format(balanceTotal).substring(1);
  income.textContent = formatter.format(incomeTotal);
  expense.textContent = formatter.format(expenseTotal * -1);
}

function renderList() {
  list.innerHTML = "";

  status.textContent = "";
  if (transactions.length === 0) {
    status.textContent = "No transactions.";
    return;
  }

  transactions.forEach(({ id, name, amount, date, type }) => {
    const sign = "income" === type ? 1 : -1;

    const li = document.createElement("li");

    li.innerHTML = `
      <div class="name">
        <h4>${name}</h4>
        <p>${formatDate(date)}</p> <!-- Format date as DD/MM/YY -->
      </div>

      <div class="amount ${type}">
        <span>${formatter.format(amount * sign)}</span>
      </div>
    
      <div class="action">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" onclick="deleteTransaction(${id})">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </div>
    `;

    list.appendChild(li);
  });
}

// Format date as DD/MM/YY
function formatDate(date) {
  const d = new Date(date);
  const day = ("0" + d.getDate()).slice(-2);
  const month = ("0" + (d.getMonth() + 1)).slice(-2);
  const year = d.getFullYear().toString().slice(-2); // Get last two digits of the year
  return `${day}/${month}/${year}`;
}

function deleteTransaction(id) {
  const index = transactions.findIndex((trx) => trx.id === id);
  transactions.splice(index, 1);

  updateTotal();
  saveTransactions();
  renderList();
  updateChart();
}

function addTransaction(e) {
  e.preventDefault();

  const formData = new FormData(this);

  transactions.push({
    id: transactions.length + 1,
    name: formData.get("name"),
    amount: parseFloat(formData.get("amount")),
    date: new Date(formData.get("date")),
    type: formData.get("type") === "on" ? "income" : "expense",
  });

  this.reset();

  updateTotal();
  saveTransactions();
  renderList();
  updateChart();
}

function saveTransactions() {
  // Sort transactions in ascending order by date (oldest to newest)
  transactions.sort((a, b) => new Date(a.date) - new Date(b.date));

  localStorage.setItem("transactions", JSON.stringify(transactions));
}

function updateChart() {
  const incomeData = [];
  const expenseData = [];
  const dates = [];

  // Organize transactions by date for the chart
  transactions.forEach((trx) => {
    const date = formatDate(trx.date); // Use formatted date
    const sign = trx.type === "income" ? 1 : -1;

    if (!dates.includes(date)) {
      dates.push(date);
    }

    if (trx.type === "income") {
      incomeData.push({ x: date, y: trx.amount });
    } else if (trx.type === "expense") {
      expenseData.push({ x: date, y: trx.amount });
    }
  });

  // Update chart data
  chart.data.labels = dates;
  chart.data.datasets[0].data = incomeData;
  chart.data.datasets[1].data = expenseData;
  chart.update();
}

// Initialize with existing data
renderList();
updateTotal();
updateChart();
