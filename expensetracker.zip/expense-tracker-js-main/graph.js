
// Get the canvas element
const ctx = document.getElementById("transactionChart").getContext("2d");

// Function to update the chart with the current data
function updateChart() {
  const incomeData = [];
  const expenseData = [];

  // Iterate over transactions and accumulate data for the chart
  transactions.forEach((trx) => {
    const date = new Date(trx.date).toLocaleDateString();

    if (trx.type === "income") {
      incomeData.push({ x: date, y: trx.amount });
    } else if (trx.type === "expense") {
      expenseData.push({ x: date, y: trx.amount });
    }
  });

  // Create the chart
  const transactionChart = new Chart(ctx, {
    type: "line", // Line chart type
    data: {
      datasets: [
        {
          label: "Income",
          data: incomeData,
          borderColor: "green",
          fill: false,
          tension: 0.1,
          pointBackgroundColor: "green",
        },
        {
          label: "Expense",
          data: expenseData,
          borderColor: "red",
          fill: false,
          tension: 0.1,
          pointBackgroundColor: "red",
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        x: {
          type: "timeseries", // Display dates on the x-axis
          time: {
            unit: "day", // Show data by day
            tooltipFormat: "ll",
          },
        },
        y: {
          ticks: {
            beginAtZero: true,
            callback: function (value) {
              return "₹" + value; // Format the y-axis values as currency
            },
          },
        },
      },
    },
  });
}

// Call the updateChart function to display the chart
updateChart();
